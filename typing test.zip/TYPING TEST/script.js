const textContainer = document.getElementById('textContainer');
const userInput = document.getElementById('userInput');
const startPauseTestBtn = document.getElementById('startPauseTest');
const timerDisplay = document.getElementById('timer');
const wpmDisplay = document.getElementById('wpm');
const accuracyDisplay = document.getElementById('accuracy');
const resultsSection = document.getElementById('results');

// Sample texts for typing
const sampleTexts = [
  "The quick brown fox jumps over the lazy dog.",
  "Practice makes perfect when it comes to typing skills.",
  "Typing fast and accurately is an essential skill in the digital age.",
];

// Variables
let timer = 0;
let interval = null;
let started = false;
let paused = false;
let currentText = "";

// Start or Pause Test
function startOrPauseTest() {
  if (!started) {
    startTest();
    startPauseTestBtn.textContent = "Pause Test";
  } else if (!paused) {
    pauseTest();
    startPauseTestBtn.textContent = "Resume Test";
  } else {
    resumeTest();
    startPauseTestBtn.textContent = "Pause Test";
  }
}

// Start the test
function startTest() {
  // Reset everything
  timer = 0;
  timerDisplay.textContent = 0;
  wpmDisplay.textContent = 0;
  accuracyDisplay.textContent = 0;
  userInput.value = "";
  userInput.disabled = false;
  userInput.focus();
  resultsSection.style.display = "none";

  // Pick random text
  currentText = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
  textContainer.textContent = currentText;

  started = true;
  paused = false;
}

// Resume Test
function resumeTest() {
  paused = false;
  userInput.disabled = false;

  // Start the timer again
  interval = setInterval(() => {
    timer++;
    timerDisplay.textContent = timer;
  }, 1000);
}

// Pause Test
function pauseTest() {
  paused = true;
  userInput.disabled = true;
  clearInterval(interval);
}

// Update input feedback and check completion
function updateUserInput() {
  if (!interval && !paused) {
    // Start timer only when typing begins
    interval = setInterval(() => {
      timer++;
      timerDisplay.textContent = timer;
    }, 1000);
  }

  const typedText = userInput.value;
  let formattedText = "";
  let isComplete = true;

  for (let i = 0; i < currentText.length; i++) {
    if (i < typedText.length) {
      if (typedText[i] === currentText[i]) {
        formattedText += `<span class="matched">${currentText[i]}</span>`;
      } else {
        formattedText += `<span class="mismatched">${currentText[i]}</span>`;
        isComplete = false; // Mark incomplete if there's a mismatch
      }
    } else {
      formattedText += `<span class="remaining">${currentText[i]}</span>`;
      isComplete = false; // Mark incomplete if text is not fully typed
    }
  }

  textContainer.innerHTML = formattedText;

  // Automatically end the test when the text is fully and correctly typed
  if (isComplete && typedText.length === currentText.length) {
    endTest();
    calculateStats();
    resultsSection.style.display = "block";
  }
}

// Calculate and display results
function calculateStats() {
  const typedText = userInput.value.trim();
  const wordsTyped = typedText.split(/\s+/).length;
  const correctChars = [...typedText].filter((char, i) => char === currentText[i]).length;

  const wpm = Math.round((wordsTyped / timer) * 60);
  const accuracy = Math.round((correctChars / currentText.length) * 100);

  wpmDisplay.textContent = wpm || 0;
  accuracyDisplay.textContent = accuracy || 0;
}

// End test
function endTest() {
  clearInterval(interval);
  userInput.disabled = true;
  started = false;
  paused = false;
  startPauseTestBtn.textContent = "Start Test";
}

// Event Listeners
startPauseTestBtn.addEventListener("click", startOrPauseTest);
userInput.addEventListener("input", updateUserInput);